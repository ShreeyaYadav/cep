# Jupiter Import & Export Management System

A complete, functional, professional web application built for a TYBSc Computer Science mini-project.

## Features Included
- **Authentication**: Secure login with PHP sessions and password hashing.
- **Dashboard**: Real-time business statistics and charts (Chart.js).
- **Product Management**: Full CRUD operations with stock alerts.
- **Supplier & Customer Management**: Manage business partners.
- **Import Transactions**: Purchase orders. When status changes to *Received*, inventory automatically increases.
- **Export Transactions**: Sales orders. System checks available stock before creation. Stock automatically decreases.
- **Inventory Management**: Real-time tracking and transaction history.
- **Invoices**: Automatically generated for exports. A4 printable format.
- **Reports**: Summary metrics filterable by date range.
- **Profile**: Update personal details and password.
- **Clean UI**: Professional, business-oriented design with Bootstrap 5. Mobile responsive.

## Technology Stack
- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript, Chart.js, Bootstrap Icons
- **Backend**: PHP 8+ (PDO for secure database access)
- **Database**: MySQL

## Installation (XAMPP)
1. **Install XAMPP** and start the **Apache** and **MySQL** modules.
2. **Move Project**: Place the `jupiter-import-export` folder inside the XAMPP `htdocs` directory (e.g. `C:\xampp\htdocs\jupiter-import-export`).
3. **Database Setup**:
   - Open your browser and go to `http://localhost/phpmyadmin/`.
   - The database is created automatically when you import the script.
   - Click on **Import**, choose the file `database/jupiter_import_export.sql` located inside the project folder, and click **Go**.
4. **Configuration**:
   - The default XAMPP credentials (`root` and no password) are set in `config/database.php`. If your setup is different, modify this file.
5. **Run Application**:
   - Open your browser and go to `http://localhost/jupiter-import-export/`.

## Admin Credentials
- **Email**: `admin@jupiter.com`
- **Password**: `admin123`

## Academic Note
This project demonstrates proficiency in standard web development technologies and practices including relational database design, basic server-side logic, session management, and responsive frontend design without relying heavily on modern JavaScript frameworks. Code structure is deliberately kept simple and transparent for evaluation purposes.
