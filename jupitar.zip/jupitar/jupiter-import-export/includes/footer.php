<?php
// includes/footer.php
$base_url = '/jupiter-import-export';
?>
            </div> <!-- end content-container -->
        </div> <!-- end main-content -->
    </div> <!-- end wrapper -->

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo $base_url; ?>/assets/js/app.js"></script>
</body>
</html>
