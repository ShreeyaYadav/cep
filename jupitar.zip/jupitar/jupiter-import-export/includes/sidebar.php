<?php
// includes/sidebar.php
$base_url = '/jupiter-import-export';
$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
?>
<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h4 class="mb-0 text-white"><i class="bi bi-globe-central-south-asia me-2"></i>Jupiter</h4>
        <small class="text-white-50">Import & Export</small>
    </div>

    <ul class="list-unstyled components">
        <li class="<?php echo ($current_dir == 'admin' && $current_page == 'dashboard.php') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        </li>
        
        <p class="sidebar-heading">Management</p>
        <li class="<?php echo ($current_dir == 'products') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/products/index.php"><i class="bi bi-box-seam"></i> Products</a>
        </li>
        <li class="<?php echo ($current_dir == 'suppliers') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/suppliers/index.php"><i class="bi bi-truck"></i> Suppliers</a>
        </li>
        <li class="<?php echo ($current_dir == 'customers') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/customers/index.php"><i class="bi bi-people"></i> Customers</a>
        </li>

        <p class="sidebar-heading">Transactions</p>
        <li class="<?php echo ($current_dir == 'imports') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/imports/index.php"><i class="bi bi-box-arrow-in-right"></i> Imports</a>
        </li>
        <li class="<?php echo ($current_dir == 'exports') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/exports/index.php"><i class="bi bi-box-arrow-right"></i> Exports</a>
        </li>
        <li class="<?php echo ($current_dir == 'inventory') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/inventory/index.php"><i class="bi bi-clipboard-data"></i> Inventory</a>
        </li>

        <p class="sidebar-heading">Billing</p>
        <li class="<?php echo ($current_dir == 'invoices') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/invoices/index.php"><i class="bi bi-receipt"></i> Invoices</a>
        </li>

        <p class="sidebar-heading">Analytics</p>
        <li class="<?php echo ($current_dir == 'reports') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/reports/index.php"><i class="bi bi-graph-up"></i> Reports</a>
        </li>

        <p class="sidebar-heading">Account</p>
        <li class="<?php echo ($current_dir == 'profile') ? 'active' : ''; ?>">
            <a href="<?php echo $base_url; ?>/admin/profile/index.php"><i class="bi bi-person-circle"></i> Profile</a>
        </li>
        <li>
            <a href="<?php echo $base_url; ?>/auth/logout.php" class="text-danger"><i class="bi bi-box-arrow-left"></i> Logout</a>
        </li>
    </ul>
</nav>
