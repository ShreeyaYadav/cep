<?php
// includes/functions.php
session_start();

function redirect($url) {
    header("Location: $url");
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        redirect('/jupiter-import-export/auth/login.php');
    }
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function setFlashMessage($key, $message) {
    $_SESSION['flash'][$key] = $message;
}

function displayFlashMessage($key) {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return '';
}

function updateInventoryOnImport($conn, $product_id, $quantity) {
    $stmt = $conn->prepare("UPDATE inventory SET quantity = quantity + ?, available_quantity = available_quantity + ? WHERE product_id = ?");
    return $stmt->execute([$quantity, $quantity, $product_id]);
}

function validateStockForExport($conn, $product_id, $quantity) {
    $stmt = $conn->prepare("SELECT available_quantity FROM inventory WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $stock = $stmt->fetch(PDO::FETCH_ASSOC);
    return ($stock && $stock['available_quantity'] >= $quantity);
}

function updateInventoryOnExport($conn, $product_id, $quantity) {
    $stmt = $conn->prepare("UPDATE inventory SET quantity = quantity - ?, available_quantity = available_quantity - ? WHERE product_id = ?");
    return $stmt->execute([$quantity, $quantity, $product_id]);
}

function recordInventoryTransaction($conn, $product_id, $type, $ref_id, $qty, $balance, $user_id) {
    $stmt = $conn->prepare("INSERT INTO inventory_transactions (product_id, transaction_type, reference_id, quantity, balance_after, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    return $stmt->execute([$product_id, $type, $ref_id, $qty, $balance, $user_id]);
}
?>
