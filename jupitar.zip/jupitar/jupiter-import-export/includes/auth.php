<?php
// includes/auth.php
require_once __DIR__ . '/functions.php';

// Ensure user is logged in for all pages that include this file
requireLogin();
?>
