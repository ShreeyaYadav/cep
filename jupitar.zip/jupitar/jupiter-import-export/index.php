<?php
// index.php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: /jupiter-import-export/admin/dashboard.php");
} else {
    header("Location: /jupiter-import-export/auth/login.php");
}
exit();
?>
