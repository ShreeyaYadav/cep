<?php
$host = 'localhost';
$username = 'root';
$password = ''; // If your XAMPP MySQL has a password, enter it here

try {
    // Connect to MySQL server without specifying a database
    $conn = new PDO("mysql:host={$host}", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Read the SQL file
    $sql_file = __DIR__ . '/database/jupiter_import_export.sql';
    
    if (file_exists($sql_file)) {
        $sql = file_get_contents($sql_file);
        
        // Execute the SQL to create the DB and tables
        $conn->exec($sql);
        echo "<h2 style='color: green;'>Database imported successfully!</h2>";
        echo "<p>You can now go to the <a href='auth/login.php'>Login Page</a>.</p>";
        
        // Delete this script for security
        unlink(__FILE__);
    } else {
        echo "<h2 style='color: red;'>Error: SQL file not found.</h2>";
    }
} catch (PDOException $e) {
    echo "<h2 style='color: red;'>Database Connection Error</h2>";
    echo "<p><strong>Message:</strong> " . $e->getMessage() . "</p>";
    echo "<p>If you have set a MySQL root password in XAMPP, you need to edit this file (<code>setup_db.php</code>) and add your password on line 4.</p>";
}
?>
