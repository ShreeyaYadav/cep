<?php

$host = '127.0.0.1';
$port = '3307';
$db_name = 'jupiter_import_export';
$username = 'root';
$password = '1234';

try {
    $conn = new PDO(
        "mysql:host={$host};port={$port};dbname={$db_name}",
        $username,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    die("Database connection failed: " . $exception->getMessage());
}
?>