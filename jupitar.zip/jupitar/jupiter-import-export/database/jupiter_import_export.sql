-- phpMyAdmin SQL Dump
-- version 5.2.1
-- Database: `jupiter_import_export`
--

CREATE DATABASE IF NOT EXISTS `jupiter_import_export` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `jupiter_import_export`;

-- --------------------------------------------------------

-- Table structure for table `users`
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','staff') NOT NULL DEFAULT 'staff',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `products`
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `unit` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `reorder_level` int(11) NOT NULL DEFAULT 10,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `suppliers`
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(50) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `customers`
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(50) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `inventory`
CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `reserved_quantity` int(11) NOT NULL DEFAULT 0,
  `available_quantity` int(11) NOT NULL DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `imports`
CREATE TABLE `imports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_number` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `import_date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `customs_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Pending','In Transit','Received','Cancelled') NOT NULL DEFAULT 'Pending',
  `remarks` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `import_number` (`import_number`),
  FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `exports`
CREATE TABLE `exports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `export_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `export_date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Pending','Processing','Shipped','Delivered','Cancelled') NOT NULL DEFAULT 'Pending',
  `remarks` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `export_number` (`export_number`),
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `inventory_transactions`
CREATE TABLE `inventory_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `transaction_type` enum('IMPORT','EXPORT','ADJUSTMENT') NOT NULL,
  `reference_id` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `invoices`
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `invoice_type` enum('EXPORT','STANDARD') NOT NULL DEFAULT 'EXPORT',
  `export_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_date` date NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `shipping` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(12,2) NOT NULL,
  `payment_status` enum('Paid','Pending','Partial','Cancelled') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  FOREIGN KEY (`export_id`) REFERENCES `exports`(`id`),
  FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table structure for table `invoice_items`
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

-- Insert Demo Data
-- Admin password is 'admin123'
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`) VALUES
(1, 'Admin User', 'admin@jupiter.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');

INSERT INTO `products` (`id`, `product_code`, `product_name`, `category`, `description`, `unit`, `price`, `reorder_level`) VALUES
(1, 'PRD-001', 'Industrial CNC Machine X1', 'Industrial Machinery', 'High precision CNC routing machine', 'Piece', 45000.00, 2),
(2, 'PRD-002', 'Copper Wire Roll 50m', 'Electronic Components', 'High conductivity pure copper wire', 'Roll', 120.00, 50),
(3, 'PRD-003', 'LED Floodlight 100W', 'LED Lighting', 'Outdoor waterproof LED floodlight', 'Piece', 45.00, 100),
(4, 'PRD-004', 'Automobile Brake Pads Set', 'Automobile Parts', 'Ceramic brake pads for commercial vehicles', 'Set', 35.00, 200),
(5, 'PRD-005', 'Corrugated Box 20x20', 'Packaging Materials', 'Heavy duty shipping boxes', 'Bundle', 15.00, 500),
(6, 'PRD-006', 'Cotton Fabric Roll 100m', 'Textile Fabric', 'Premium quality 100% cotton fabric', 'Roll', 250.00, 20),
(7, 'PRD-007', 'Wireless Mouse Pro', 'Computer Accessories', 'Ergonomic wireless mouse', 'Piece', 25.00, 150),
(8, 'PRD-008', 'Mechanical Keyboard', 'Computer Accessories', 'RGB mechanical keyboard with blue switches', 'Piece', 55.00, 80),
(9, 'PRD-009', 'Hydraulic Pump 5HP', 'Industrial Machinery', 'Heavy duty industrial hydraulic pump', 'Piece', 850.00, 5),
(10, 'PRD-010', 'Circuit Board FR4', 'Electronic Components', 'Blank FR4 PCB boards', 'Pack', 40.00, 100);

INSERT INTO `inventory` (`product_id`, `quantity`, `reserved_quantity`, `available_quantity`) VALUES
(1, 5, 0, 5),
(2, 200, 0, 200),
(3, 150, 0, 150),
(4, 300, 0, 300),
(5, 1000, 0, 1000),
(6, 50, 0, 50),
(7, 400, 0, 400),
(8, 200, 0, 200),
(9, 10, 0, 10),
(10, 500, 0, 500);

INSERT INTO `suppliers` (`id`, `supplier_code`, `company_name`, `contact_person`, `email`, `phone`, `address`, `city`, `country`) VALUES
(1, 'SUP-001', 'Global Machinery Pvt. Ltd.', 'Rajesh Kumar', 'contact@globalmachinery.in', '+91 9876543210', 'MIDC Industrial Area', 'Mumbai', 'India'),
(2, 'SUP-002', 'Shanghai Industrial Trading Co.', 'Wei Chen', 'sales@shanghaiind.cn', '+86 13800138000', 'Pudong New Area', 'Shanghai', 'China'),
(3, 'SUP-003', 'Dubai General Trading LLC', 'Ahmed Al Maktoum', 'info@dubaigeneral.ae', '+971 501234567', 'Deira', 'Dubai', 'UAE'),
(4, 'SUP-004', 'Tokyo Electronics Corporation', 'Kenji Sato', 'export@tokyoelec.jp', '+81 9012345678', 'Shinjuku', 'Tokyo', 'Japan'),
(5, 'SUP-005', 'German Auto Parts GmbH', 'Hans Weber', 'sales@germanauto.de', '+49 15112345678', 'Industrial Park', 'Munich', 'Germany');

INSERT INTO `customers` (`id`, `customer_code`, `company_name`, `contact_person`, `email`, `phone`, `address`, `city`, `country`) VALUES
(1, 'CUS-001', 'Jupiter Retail Pvt. Ltd.', 'Amit Sharma', 'purchase@jupiterretail.in', '+91 9123456780', 'Andheri East', 'Mumbai', 'India'),
(2, 'CUS-002', 'Global Trade Solutions', 'Sarah Johnson', 'procurement@globaltrade.com', '+1 555-0123', 'Manhattan', 'New York', 'USA'),
(3, 'CUS-003', 'Delhi Electronics Hub', 'Vikram Singh', 'info@delhielectronics.in', '+91 9988776655', 'Nehru Place', 'New Delhi', 'India'),
(4, 'CUS-004', 'Euro Tech Supplies', 'Marcus Schmidt', 'import@eurotech.de', '+49 1701122334', 'Business Center', 'Berlin', 'Germany'),
(5, 'CUS-005', 'Gulf Traders', 'Mohammed Ali', 'sales@gulftraders.ae', '+971 559988776', 'JAFZA', 'Dubai', 'UAE');

-- Dummy imports
INSERT INTO `imports` (`id`, `import_number`, `supplier_id`, `import_date`, `product_id`, `quantity`, `unit_cost`, `total_amount`, `shipping_cost`, `customs_cost`, `status`, `remarks`, `created_by`) VALUES
(1, 'IMP-1001', 1, '2023-10-01', 1, 2, 40000.00, 82000.00, 1000.00, 1000.00, 'Received', 'Initial stock', 1),
(2, 'IMP-1002', 2, '2023-10-05', 2, 100, 100.00, 10500.00, 500.00, 0.00, 'Received', 'Urgent stock', 1);

-- Dummy exports
INSERT INTO `exports` (`id`, `export_number`, `customer_id`, `export_date`, `product_id`, `quantity`, `unit_price`, `total_amount`, `shipping_cost`, `tax`, `status`, `remarks`, `created_by`) VALUES
(1, 'EXP-2001', 1, '2023-10-10', 2, 50, 150.00, 8000.00, 500.00, 0.00, 'Shipped', 'First dispatch', 1),
(2, 'EXP-2002', 2, '2023-10-12', 3, 20, 60.00, 1300.00, 100.00, 0.00, 'Processing', 'Standard delivery', 1);

-- Dummy invoices
INSERT INTO `invoices` (`id`, `invoice_number`, `invoice_type`, `export_id`, `customer_id`, `invoice_date`, `subtotal`, `tax`, `shipping`, `grand_total`, `payment_status`) VALUES
(1, 'INV-2023001', 'EXPORT', 1, 1, '2023-10-10', 7500.00, 0.00, 500.00, 8000.00, 'Paid'),
(2, 'INV-2023002', 'EXPORT', 2, 2, '2023-10-12', 1200.00, 0.00, 100.00, 1300.00, 'Pending');

INSERT INTO `invoice_items` (`id`, `invoice_id`, `product_id`, `quantity`, `unit_price`, `total`) VALUES
(1, 1, 2, 50, 150.00, 7500.00),
(2, 2, 3, 20, 60.00, 1200.00);

