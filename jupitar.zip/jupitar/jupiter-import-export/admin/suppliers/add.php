<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplier_code = trim($_POST['supplier_code']);
    $company_name = trim($_POST['company_name']);
    $contact_person = trim($_POST['contact_person']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $country = trim($_POST['country']);
    $status = trim($_POST['status']);
    
    // Check if code exists
    $stmt = $conn->prepare("SELECT id FROM suppliers WHERE supplier_code = ?");
    $stmt->execute([$supplier_code]);
    if ($stmt->rowCount() > 0) {
        $error = 'Supplier Code already exists.';
    } else {
        $query = "INSERT INTO suppliers (supplier_code, company_name, contact_person, email, phone, address, city, country, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if ($stmt->execute([$supplier_code, $company_name, $contact_person, $email, $phone, $address, $city, $country, $status])) {
            
            setFlashMessage('success', 'Supplier added successfully.');
            redirect('/jupiter-import-export/admin/suppliers/index.php');
        } else {
            $error = 'Failed to add supplier.';
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Add Supplier</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier Code <span class='text-danger'>*</span></label>
                    <input type="text" name="supplier_code" class="form-control" required >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Company Name <span class='text-danger'>*</span></label>
                    <input type="text" name="company_name" class="form-control" required >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Contact Person </label>
                    <input type="text" name="contact_person" class="form-control"  >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email </label>
                    <input type="email" name="email" class="form-control"  >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone </label>
                    <input type="text" name="phone" class="form-control"  >
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address </label>
                    <textarea name="address" class="form-control" ></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">City </label>
                    <input type="text" name="city" class="form-control"  >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Country </label>
                    <input type="text" name="country" class="form-control"  >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status <span class='text-danger'>*</span></label>
                    <select name="status" class="form-select" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-primary">Save Supplier</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
