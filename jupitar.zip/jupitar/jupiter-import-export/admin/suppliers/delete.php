<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/suppliers/index.php');
}

$id = (int)$_GET['id'];
$stmt = $conn->prepare("DELETE FROM suppliers WHERE id = ?");
try {
    if ($stmt->execute([$id])) {
        setFlashMessage('success', 'Record deleted successfully.');
    } else {
        setFlashMessage('error', 'Failed to delete record.');
    }
} catch (PDOException $e) {
    setFlashMessage('error', 'Cannot delete this record because it is referenced in other transactions.');
}
redirect('/jupiter-import-export/admin/suppliers/index.php');
?>
