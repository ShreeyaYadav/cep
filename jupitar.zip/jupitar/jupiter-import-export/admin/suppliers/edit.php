<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/suppliers/index.php');
}

$id = (int)$_GET['id'];
$error = '';

$stmt = $conn->prepare("SELECT * FROM suppliers WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    redirect('/jupiter-import-export/admin/suppliers/index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplier_code = trim($_POST['supplier_code']);
    $company_name = trim($_POST['company_name']);
    $contact_person = trim($_POST['contact_person']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $country = trim($_POST['country']);
    $status = trim($_POST['status']);
    
    // Check if code exists for another ID
    $stmt = $conn->prepare("SELECT id FROM suppliers WHERE supplier_code = ? AND id != ?");
    $stmt->execute([$supplier_code, $id]);
    if ($stmt->rowCount() > 0) {
        $error = 'Supplier Code already exists.';
    } else {
        $query = "UPDATE suppliers SET supplier_code = ?, company_name = ?, contact_person = ?, email = ?, phone = ?, address = ?, city = ?, country = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $exec_vars = [$supplier_code, $company_name, $contact_person, $email, $phone, $address, $city, $country, $status, $id];
        if ($stmt->execute($exec_vars)) {
            setFlashMessage('success', 'Supplier updated successfully.');
            redirect('/jupiter-import-export/admin/suppliers/index.php');
        } else {
            $error = 'Failed to update supplier.';
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Edit Supplier</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier Code <span class='text-danger'>*</span></label>
                    <input type="text" name="supplier_code" class="form-control" required  value="<?php echo htmlspecialchars($item["supplier_code"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Company Name <span class='text-danger'>*</span></label>
                    <input type="text" name="company_name" class="form-control" required  value="<?php echo htmlspecialchars($item["company_name"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Contact Person </label>
                    <input type="text" name="contact_person" class="form-control"   value="<?php echo htmlspecialchars($item["contact_person"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email </label>
                    <input type="email" name="email" class="form-control"   value="<?php echo htmlspecialchars($item["email"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone </label>
                    <input type="text" name="phone" class="form-control"   value="<?php echo htmlspecialchars($item["phone"]); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address </label>
                    <textarea name="address" class="form-control" ><?php echo htmlspecialchars($item["address"]); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">City </label>
                    <input type="text" name="city" class="form-control"   value="<?php echo htmlspecialchars($item["city"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Country </label>
                    <input type="text" name="country" class="form-control"   value="<?php echo htmlspecialchars($item["country"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status <span class='text-danger'>*</span></label>
                    <select name="status" class="form-select" required>
                <option value="active" <?php echo $item["status"] == 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="inactive" <?php echo $item["status"] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
            </select>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-primary">Update Supplier</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
