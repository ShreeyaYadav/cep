<?php
// admin/profile/index.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$user_id = $_SESSION['user_id'];
$error = '';

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    
    // check unique email
    $chk = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $chk->execute([$email, $user_id]);
    if ($chk->rowCount() > 0) {
        $error = "Email is already in use.";
    } else {
        $upd = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        if ($upd->execute([$name, $email, $user_id])) {
            $_SESSION['user_name'] = $name;
            setFlashMessage('success', 'Profile updated successfully.');
            redirect('/jupiter-import-export/admin/profile/index.php');
        } else {
            $error = "Failed to update profile.";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    
    if (password_verify($current, $user['password'])) {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($upd->execute([$hash, $user_id])) {
            setFlashMessage('success', 'Password changed successfully.');
            redirect('/jupiter-import-export/admin/profile/index.php');
        }
    } else {
        $error = "Current password is incorrect.";
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">My Profile</h2>
</div>

<?php if ($msg = displayFlashMessage('success')): ?>
    <div class="alert alert-success"><?php echo $msg; ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0">Update Profile Details</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($user['name']); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($user['email']); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <input type="text" class="form-control" disabled value="<?php echo ucfirst($user['role']); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-white">
                <h6 class="mb-0">Change Password</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="update_password" value="1">
                    <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                    </div>
                    <button type="submit" class="btn btn-warning">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
