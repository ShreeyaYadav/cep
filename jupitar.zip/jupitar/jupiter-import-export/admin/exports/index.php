<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$query = "SELECT e.*, p.product_name, c.company_name as customer_name 
          FROM exports e 
          JOIN products p ON e.product_id = p.id 
          JOIN customers c ON e.customer_id = c.id 
          WHERE e.export_number LIKE :search OR c.company_name LIKE :search 
          ORDER BY e.id DESC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($query);
$search_param = "%$search%";
$stmt->bindParam(':search', $search_param, PDO::PARAM_STR);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$count_query = "SELECT COUNT(*) FROM exports e JOIN customers c ON e.customer_id = c.id WHERE e.export_number LIKE :search OR c.company_name LIKE :search";
$count_stmt = $conn->prepare($count_query);
$count_stmt->execute(['search' => $search_param]);
$total_pages = ceil($count_stmt->fetchColumn() / $limit);

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Exports</h2>
    <a href="add.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> New Export</a>
</div>

<?php if ($msg = displayFlashMessage('success')): ?>
    <div class="alert alert-success"><?php echo $msg; ?></div>
<?php endif; ?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white py-3">
        <form class="d-flex align-items-center" method="GET">
            <input type="text" name="search" class="form-control me-2" placeholder="Search by export number or customer..." value="<?php echo htmlspecialchars($search); ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Export No.</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($items) > 0): ?>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['export_number']); ?></td>
                            <td><?php echo date('d M Y', strtotime($item['export_date'])); ?></td>
                            <td><?php echo htmlspecialchars($item['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>$<?php echo number_format($item['total_amount'], 2); ?></td>
                            <td>
                                <?php 
                                $bg = 'secondary';
                                if($item['status'] == 'Delivered') $bg = 'success';
                                elseif($item['status'] == 'Shipped') $bg = 'info';
                                elseif($item['status'] == 'Processing') $bg = 'primary';
                                elseif($item['status'] == 'Pending') $bg = 'warning text-dark';
                                elseif($item['status'] == 'Cancelled') $bg = 'danger';
                                ?>
                                <span class="badge bg-<?php echo $bg; ?>"><?php echo $item['status']; ?></span>
                            </td>
                            <td>
                                <a href="view.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> View</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4">No exports found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
