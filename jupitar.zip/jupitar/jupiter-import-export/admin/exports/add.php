<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$error = '';

$customers = $conn->query("SELECT id, company_name FROM customers WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);
$products = $conn->query("
    SELECT p.id, p.product_name, p.price, i.available_quantity 
    FROM products p 
    JOIN inventory i ON p.id = i.product_id 
    WHERE p.status = 'active'
")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $export_number = trim($_POST['export_number']);
    $customer_id = (int)$_POST['customer_id'];
    $export_date = $_POST['export_date'];
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    $unit_price = (float)$_POST['unit_price'];
    $shipping_cost = (float)$_POST['shipping_cost'];
    $tax = (float)$_POST['tax'];
    $remarks = trim($_POST['remarks']);
    
    $subtotal = $quantity * $unit_price;
    $total_amount = $subtotal + $shipping_cost + $tax;
    
    // Check inventory FIRST
    if (!validateStockForExport($conn, $product_id, $quantity)) {
        // Fetch current available stock
        $stmt_s = $conn->prepare("SELECT available_quantity FROM inventory WHERE product_id = ?");
        $stmt_s->execute([$product_id]);
        $avail = $stmt_s->fetchColumn();
        $error = "Insufficient stock. Available quantity: {$avail}.";
    } else {
        // check unique export number
        $stmt = $conn->prepare("SELECT id FROM exports WHERE export_number = ?");
        $stmt->execute([$export_number]);
        if ($stmt->rowCount() > 0) {
            $error = 'Export Number already exists.';
        } elseif ($quantity <= 0) {
            $error = 'Quantity must be greater than zero.';
        } else {
            // We will create the export as Processing directly to deduct stock immediately as requested
            $query = "INSERT INTO exports (export_number, customer_id, export_date, product_id, quantity, unit_price, total_amount, shipping_cost, tax, status, remarks, created_by) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Processing', ?, ?)";
            $stmt = $conn->prepare($query);
            
            $conn->beginTransaction();
            try {
                $stmt->execute([$export_number, $customer_id, $export_date, $product_id, $quantity, $unit_price, $total_amount, $shipping_cost, $tax, $remarks, $_SESSION['user_id']]);
                $export_id = $conn->lastInsertId();
                
                // Deduct stock
                updateInventoryOnExport($conn, $product_id, $quantity);
                
                // Fetch balance
                $bal_stmt = $conn->prepare("SELECT available_quantity FROM inventory WHERE product_id = ?");
                $bal_stmt->execute([$product_id]);
                $balance = $bal_stmt->fetchColumn();
                
                // Record transaction
                recordInventoryTransaction($conn, $product_id, 'EXPORT', $export_number, $quantity, $balance, $_SESSION['user_id']);
                
                // Automatically generate Invoice
                $invoice_number = 'INV-' . time();
                $inv_query = "INSERT INTO invoices (invoice_number, invoice_type, export_id, customer_id, invoice_date, subtotal, tax, shipping, grand_total) 
                              VALUES (?, 'EXPORT', ?, ?, ?, ?, ?, ?, ?)";
                $inv_stmt = $conn->prepare($inv_query);
                $inv_stmt->execute([$invoice_number, $export_id, $customer_id, $export_date, $subtotal, $tax, $shipping_cost, $total_amount]);
                
                $invoice_id = $conn->lastInsertId();
                $item_query = "INSERT INTO invoice_items (invoice_id, product_id, quantity, unit_price, total) VALUES (?, ?, ?, ?, ?)";
                $item_stmt = $conn->prepare($item_query);
                $item_stmt->execute([$invoice_id, $product_id, $quantity, $unit_price, $subtotal]);
                
                $conn->commit();
                
                setFlashMessage('success', 'Export created successfully, inventory deducted, and invoice generated.');
                redirect('/jupiter-import-export/admin/exports/view.php?id=' . $export_id);
            } catch (Exception $e) {
                $conn->rollBack();
                $error = 'Failed to create export. Error: ' . $e->getMessage();
            }
        }
    }
}

include '../../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">New Export</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Export Number <span class="text-danger">*</span></label>
                    <input type="text" name="export_number" class="form-control" required value="EXP-<?php echo time(); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Export Date <span class="text-danger">*</span></label>
                    <input type="date" name="export_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Customer <span class="text-danger">*</span></label>
                    <select name="customer_id" class="form-select" required>
                        <option value="">Select Customer</option>
                        <?php foreach($customers as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['company_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product <span class="text-danger">*</span></label>
                    <select name="product_id" id="product_id" class="form-select" required onchange="updatePriceAndStock()">
                        <option value="" data-price="0" data-stock="0">Select Product</option>
                        <?php foreach($products as $p): ?>
                            <option value="<?php echo $p['id']; ?>" data-price="<?php echo $p['price']; ?>" data-stock="<?php echo $p['available_quantity']; ?>">
                                <?php echo htmlspecialchars($p['product_name']); ?> (Stock: <?php echo $p['available_quantity']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3 mb-3">
                    <label class="form-label">Quantity <span class="text-danger">*</span></label>
                    <input type="number" name="quantity" class="form-control" required min="1">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Unit Price ($) <span class="text-danger">*</span></label>
                    <input type="number" name="unit_price" id="unit_price" step="0.01" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Shipping Cost ($)</label>
                    <input type="number" name="shipping_cost" step="0.01" class="form-control" value="0">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Tax ($)</label>
                    <input type="number" name="tax" step="0.01" class="form-control" value="0">
                </div>
                
                <div class="col-md-12 mb-3">
                    <label class="form-label">Remarks</label>
                    <textarea name="remarks" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Create Export</button>
        </form>
    </div>
</div>

<script>
function updatePriceAndStock() {
    var select = document.getElementById('product_id');
    var selected = select.options[select.selectedIndex];
    var price = selected.getAttribute('data-price');
    if(price) {
        document.getElementById('unit_price').value = price;
    }
}
</script>
<?php include '../../includes/footer.php'; ?>
