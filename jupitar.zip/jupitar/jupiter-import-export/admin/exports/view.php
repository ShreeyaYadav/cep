<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/exports/index.php');
}

$id = (int)$_GET['id'];
$error = '';

$stmt = $conn->prepare("
    SELECT e.*, p.product_name, p.product_code, c.company_name, u.name as created_by_name 
    FROM exports e 
    JOIN products p ON e.product_id = p.id 
    JOIN customers c ON e.customer_id = c.id 
    JOIN users u ON e.created_by = u.id 
    WHERE e.id = ?
");
$stmt->execute([$id]);
$export = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$export) {
    redirect('/jupiter-import-export/admin/exports/index.php');
}

// Fetch invoice if exists
$inv_stmt = $conn->prepare("SELECT id FROM invoices WHERE export_id = ?");
$inv_stmt->execute([$id]);
$invoice = $inv_stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    if ($export['status'] != 'Delivered' && $export['status'] != 'Cancelled') {
        $stmt = $conn->prepare("UPDATE exports SET status = ? WHERE id = ?");
        
        if ($stmt->execute([$new_status, $id])) {
            setFlashMessage('success', 'Export status updated.');
            redirect('/jupiter-import-export/admin/exports/view.php?id=' . $id);
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Export Details: <?php echo htmlspecialchars($export['export_number']); ?></h2>
    <div>
        <?php if($invoice): ?>
        <a href="../invoices/view.php?id=<?php echo $invoice['id']; ?>" class="btn btn-info text-white"><i class="bi bi-receipt"></i> View Invoice</a>
        <?php endif; ?>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
    </div>
</div>

<?php if ($msg = displayFlashMessage('success')): ?>
    <div class="alert alert-success"><?php echo $msg; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0">Transaction Information</h6>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Customer</div>
                    <div class="col-sm-8 fw-bold"><?php echo htmlspecialchars($export['company_name']); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Date</div>
                    <div class="col-sm-8"><?php echo date('d M Y', strtotime($export['export_date'])); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Product</div>
                    <div class="col-sm-8"><?php echo htmlspecialchars($export['product_code'] . ' - ' . $export['product_name']); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Quantity</div>
                    <div class="col-sm-8"><?php echo $export['quantity']; ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Remarks</div>
                    <div class="col-sm-8"><?php echo nl2br(htmlspecialchars($export['remarks'])); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0">Financials & Status</h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Unit Price:</span>
                    <span>$<?php echo number_format($export['unit_price'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal:</span>
                    <span>$<?php echo number_format($export['quantity'] * $export['unit_price'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Shipping:</span>
                    <span>$<?php echo number_format($export['shipping_cost'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Tax:</span>
                    <span>$<?php echo number_format($export['tax'], 2); ?></span>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-3 fw-bold">
                    <span>Grand Total:</span>
                    <span class="text-primary">$<?php echo number_format($export['total_amount'], 2); ?></span>
                </div>
                
                <div class="mb-3">
                    <label class="text-muted mb-1 d-block">Current Status:</label>
                    <h5>
                        <?php 
                        $bg = 'secondary';
                        if($export['status'] == 'Delivered') $bg = 'success';
                        elseif($export['status'] == 'Shipped') $bg = 'info';
                        elseif($export['status'] == 'Processing') $bg = 'primary';
                        elseif($export['status'] == 'Cancelled') $bg = 'danger';
                        ?>
                        <span class="badge bg-<?php echo $bg; ?>"><?php echo $export['status']; ?></span>
                    </h5>
                </div>
                
                <?php if ($export['status'] != 'Delivered' && $export['status'] != 'Cancelled'): ?>
                <form method="POST" action="">
                    <input type="hidden" name="update_status" value="1">
                    <div class="mb-3">
                        <select name="status" class="form-select">
                            <option value="Processing" <?php echo $export['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="Shipped" <?php echo $export['status'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="Delivered" <?php echo $export['status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Update Status</button>
                </form>
                <?php else: ?>
                    <div class="alert alert-light border">
                        Status is final. Cannot be changed.
                    </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
