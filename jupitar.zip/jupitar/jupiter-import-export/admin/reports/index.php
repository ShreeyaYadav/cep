<?php
// admin/reports/index.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

// Import Stats
$imp_stmt = $conn->prepare("SELECT COUNT(*) as cnt, SUM(total_amount) as total FROM imports WHERE import_date BETWEEN ? AND ?");
$imp_stmt->execute([$start_date, $end_date]);
$imp_stats = $imp_stmt->fetch(PDO::FETCH_ASSOC);

// Export Stats
$exp_stmt = $conn->prepare("SELECT COUNT(*) as cnt, SUM(total_amount) as total, SUM(tax) as tax FROM exports WHERE export_date BETWEEN ? AND ?");
$exp_stmt->execute([$start_date, $end_date]);
$exp_stats = $exp_stmt->fetch(PDO::FETCH_ASSOC);

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Business Reports</h2>
    <button onclick="window.print()" class="btn btn-outline-secondary d-print-none"><i class="bi bi-printer"></i> Print Report</button>
</div>

<div class="card shadow-sm mb-4 d-print-none">
    <div class="card-body py-3">
        <form class="row g-3 align-items-end" method="GET">
            <div class="col-md-4">
                <label class="form-label">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">End Date</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Filter Report</button>
            </div>
        </form>
    </div>
</div>

<h5 class="mb-3 text-center d-none d-print-block">Business Report (<?php echo date('d M Y', strtotime($start_date)); ?> to <?php echo date('d M Y', strtotime($end_date)); ?>)</h5>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Imports Summary</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td>Total Import Orders:</td>
                        <td class="text-end fw-bold"><?php echo (int)$imp_stats['cnt']; ?></td>
                    </tr>
                    <tr>
                        <td>Total Value of Imports:</td>
                        <td class="text-end fw-bold text-info">$<?php echo number_format($imp_stats['total'] ?: 0, 2); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Exports Summary</h5>
            </div>
            <div class="card-body">
                <table class="table table-borderless">
                    <tr>
                        <td>Total Export Orders:</td>
                        <td class="text-end fw-bold"><?php echo (int)$exp_stats['cnt']; ?></td>
                    </tr>
                    <tr>
                        <td>Total Tax Collected:</td>
                        <td class="text-end fw-bold">$<?php echo number_format($exp_stats['tax'] ?: 0, 2); ?></td>
                    </tr>
                    <tr>
                        <td>Total Value of Exports:</td>
                        <td class="text-end fw-bold text-success">$<?php echo number_format($exp_stats['total'] ?: 0, 2); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Low stock
$low_stock = $conn->query("
    SELECT p.product_name, p.product_code, i.available_quantity, p.reorder_level 
    FROM inventory i 
    JOIN products p ON i.product_id = p.id 
    WHERE i.available_quantity <= p.reorder_level
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-danger text-white">
        <h6 class="mb-0">Current Low Stock Items</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Code</th>
                        <th>Product</th>
                        <th>Reorder Level</th>
                        <th>Available Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($low_stock) > 0): ?>
                        <?php foreach($low_stock as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['reorder_level']; ?></td>
                            <td class="text-danger fw-bold"><?php echo $item['available_quantity']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center py-3">No items are low on stock.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
