<?php
// admin/invoices/view.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/invoices/index.php');
}

$id = (int)$_GET['id'];

$stmt = $conn->prepare("
    SELECT i.*, c.company_name, c.address, c.city, c.country, c.email, c.phone, e.export_number 
    FROM invoices i 
    JOIN customers c ON i.customer_id = c.id 
    LEFT JOIN exports e ON i.export_id = e.id 
    WHERE i.id = ?
");
$stmt->execute([$id]);
$invoice = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$invoice) {
    redirect('/jupiter-import-export/admin/invoices/index.php');
}

$items_stmt = $conn->prepare("
    SELECT it.*, p.product_name, p.product_code 
    FROM invoice_items it 
    JOIN products p ON it.product_id = p.id 
    WHERE it.invoice_id = ?
");
$items_stmt->execute([$id]);
$invoice_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['payment_status'];
    $upd = $conn->prepare("UPDATE invoices SET payment_status = ? WHERE id = ?");
    if ($upd->execute([$new_status, $id])) {
        setFlashMessage('success', 'Payment status updated.');
        redirect('/jupiter-import-export/admin/invoices/view.php?id=' . $id);
    }
}

include '../../includes/header.php';
?>
<style>
@media print {
    body * { visibility: hidden; }
    .print-area, .print-area * { visibility: visible; }
    .print-area { position: absolute; left: 0; top: 0; width: 100%; }
    .no-print { display: none !important; }
}
.invoice-box { padding: 30px; border: 1px solid #eee; background: #fff; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4 no-print">
    <h2 class="h4 mb-0">Invoice: <?php echo htmlspecialchars($invoice['invoice_number']); ?></h2>
    <div>
        <button onclick="window.print()" class="btn btn-secondary me-2"><i class="bi bi-printer"></i> Print</button>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
    </div>
</div>

<?php if ($msg = displayFlashMessage('success')): ?>
    <div class="alert alert-success no-print"><?php echo $msg; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-9">
        <div class="card shadow-sm mb-4 print-area">
            <div class="card-body invoice-box">
                <div class="row mb-4">
                    <div class="col-sm-6">
                        <h2 class="text-primary mb-0">JUPITER</h2>
                        <div class="text-muted">Import & Export Management</div>
                        <div class="mt-3">
                            <p class="mb-0">MIDC Industrial Area</p>
                            <p class="mb-0">Mumbai, Maharashtra, India</p>
                            <p class="mb-0">Email: info@jupiter.com</p>
                            <p class="mb-0">Phone: +91 9876543210</p>
                        </div>
                    </div>
                    <div class="col-sm-6 text-sm-end">
                        <h4 class="text-uppercase text-muted">Invoice</h4>
                        <div class="mt-3">
                            <p class="mb-0"><strong>Invoice No:</strong> <?php echo htmlspecialchars($invoice['invoice_number']); ?></p>
                            <p class="mb-0"><strong>Date:</strong> <?php echo date('d M Y', strtotime($invoice['invoice_date'])); ?></p>
                            <?php if($invoice['export_number']): ?>
                            <p class="mb-0"><strong>Export Ref:</strong> <?php echo htmlspecialchars($invoice['export_number']); ?></p>
                            <?php endif; ?>
                            <p class="mb-0 mt-2">
                                <strong>Status:</strong> 
                                <span class="badge bg-<?php echo $invoice['payment_status']=='Paid'?'success':($invoice['payment_status']=='Pending'?'warning':'secondary'); ?>">
                                    <?php echo $invoice['payment_status']; ?>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row mb-4">
                    <div class="col-sm-6">
                        <h6 class="text-muted text-uppercase mb-2">Bill To:</h6>
                        <h5><?php echo htmlspecialchars($invoice['company_name']); ?></h5>
                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($invoice['address'])); ?></p>
                        <p class="mb-0"><?php echo htmlspecialchars($invoice['city'] . ', ' . $invoice['country']); ?></p>
                        <p class="mb-0">Email: <?php echo htmlspecialchars($invoice['email']); ?></p>
                        <p class="mb-0">Phone: <?php echo htmlspecialchars($invoice['phone']); ?></p>
                    </div>
                </div>
                
                <div class="table-responsive mb-4">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Item Description</th>
                                <th class="text-end">Qty</th>
                                <th class="text-end">Unit Price</th>
                                <th class="text-end">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($invoice_items as $it): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($it['product_code']); ?></strong><br>
                                    <?php echo htmlspecialchars($it['product_name']); ?>
                                </td>
                                <td class="text-end"><?php echo $it['quantity']; ?></td>
                                <td class="text-end">$<?php echo number_format($it['unit_price'], 2); ?></td>
                                <td class="text-end">$<?php echo number_format($it['total'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="row">
                    <div class="col-sm-7">
                        <p class="text-muted small"><strong>Notes:</strong><br>Please make payment within 30 days of the invoice date. All bank charges are to be borne by the remitter.</p>
                    </div>
                    <div class="col-sm-5">
                        <table class="table table-sm table-borderless text-end">
                            <tr>
                                <td><strong>Subtotal:</strong></td>
                                <td>$<?php echo number_format($invoice['subtotal'], 2); ?></td>
                            </tr>
                            <tr>
                                <td>Shipping:</td>
                                <td>$<?php echo number_format($invoice['shipping'], 2); ?></td>
                            </tr>
                            <tr>
                                <td>Tax:</td>
                                <td>$<?php echo number_format($invoice['tax'], 2); ?></td>
                            </tr>
                            <tr class="border-top">
                                <td><h5 class="mb-0">Grand Total:</h5></td>
                                <td><h5 class="mb-0 text-primary">$<?php echo number_format($invoice['grand_total'], 2); ?></h5></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3 no-print">
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Update Payment</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="update_status" value="1">
                    <div class="mb-3">
                        <select name="payment_status" class="form-select">
                            <option value="Pending" <?php echo $invoice['payment_status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Partial" <?php echo $invoice['payment_status'] == 'Partial' ? 'selected' : ''; ?>>Partial</option>
                            <option value="Paid" <?php echo $invoice['payment_status'] == 'Paid' ? 'selected' : ''; ?>>Paid</option>
                            <option value="Cancelled" <?php echo $invoice['payment_status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save Status</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
