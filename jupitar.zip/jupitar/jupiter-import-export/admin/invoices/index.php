<?php
// admin/invoices/index.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$query = "SELECT i.*, c.company_name as customer_name 
          FROM invoices i 
          JOIN customers c ON i.customer_id = c.id 
          WHERE i.invoice_number LIKE :search OR c.company_name LIKE :search 
          ORDER BY i.id DESC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($query);
$search_param = "%$search%";
$stmt->bindParam(':search', $search_param, PDO::PARAM_STR);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Invoices</h2>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white py-3">
        <form class="d-flex align-items-center" method="GET">
            <input type="text" name="search" class="form-control me-2" placeholder="Search by invoice number or customer..." value="<?php echo htmlspecialchars($search); ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Invoice No.</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Total Amount</th>
                        <th>Payment Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($items) > 0): ?>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['invoice_number']); ?></td>
                            <td><?php echo date('d M Y', strtotime($item['invoice_date'])); ?></td>
                            <td><?php echo htmlspecialchars($item['customer_name']); ?></td>
                            <td>$<?php echo number_format($item['grand_total'], 2); ?></td>
                            <td>
                                <?php 
                                $bg = 'secondary';
                                if($item['payment_status'] == 'Paid') $bg = 'success';
                                elseif($item['payment_status'] == 'Partial') $bg = 'info';
                                elseif($item['payment_status'] == 'Pending') $bg = 'warning text-dark';
                                elseif($item['payment_status'] == 'Cancelled') $bg = 'danger';
                                ?>
                                <span class="badge bg-<?php echo $bg; ?>"><?php echo $item['payment_status']; ?></span>
                            </td>
                            <td>
                                <a href="view.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> View</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center py-4">No invoices found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
