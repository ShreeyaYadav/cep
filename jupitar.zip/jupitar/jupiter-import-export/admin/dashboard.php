<?php
// admin/dashboard.php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Fetch Statistics
$stats = [
    'products' => $conn->query("SELECT COUNT(*) FROM products")->fetchColumn(),
    'suppliers' => $conn->query("SELECT COUNT(*) FROM suppliers")->fetchColumn(),
    'customers' => $conn->query("SELECT COUNT(*) FROM customers")->fetchColumn(),
    'imports' => $conn->query("SELECT COUNT(*) FROM imports")->fetchColumn(),
    'exports' => $conn->query("SELECT COUNT(*) FROM exports")->fetchColumn(),
    'total_stock' => $conn->query("SELECT SUM(available_quantity) FROM inventory")->fetchColumn() ?: 0,
    'import_val' => $conn->query("SELECT SUM(total_amount) FROM imports WHERE status = 'Received'")->fetchColumn() ?: 0,
    'export_val' => $conn->query("SELECT SUM(total_amount) FROM exports WHERE status IN ('Shipped', 'Delivered')")->fetchColumn() ?: 0,
];

// Fetch Low Stock
$low_stock = $conn->query("
    SELECT p.product_name, p.product_code, i.available_quantity, p.reorder_level 
    FROM inventory i 
    JOIN products p ON i.product_id = p.id 
    WHERE i.available_quantity <= p.reorder_level
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Recent Imports
$recent_imports = $conn->query("
    SELECT i.import_number, s.company_name, i.import_date, i.total_amount, i.status 
    FROM imports i 
    JOIN suppliers s ON i.supplier_id = s.id 
    ORDER BY i.created_at DESC LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Recent Exports
$recent_exports = $conn->query("
    SELECT e.export_number, c.company_name, e.export_date, e.total_amount, e.status 
    FROM exports e 
    JOIN customers c ON e.customer_id = c.id 
    ORDER BY e.created_at DESC LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0 text-gray-800">Dashboard</h2>
    <span>Welcome back, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></span>
</div>

<!-- Stat Cards Row -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100 py-2 border-start border-4 border-primary shadow-sm">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Products</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($stats['products']); ?></div>
                    </div>
                    <div class="col-auto"><i class="bi bi-box-seam fs-2 text-muted"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100 py-2 border-start border-4 border-success shadow-sm">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Export Value</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">$<?php echo number_format($stats['export_val'], 2); ?></div>
                    </div>
                    <div class="col-auto"><i class="bi bi-currency-dollar fs-2 text-muted"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100 py-2 border-start border-4 border-info shadow-sm">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Import Value</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">$<?php echo number_format($stats['import_val'], 2); ?></div>
                    </div>
                    <div class="col-auto"><i class="bi bi-cart-check fs-2 text-muted"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100 py-2 border-start border-4 border-warning shadow-sm">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available Stock (Units)</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($stats['total_stock']); ?></div>
                    </div>
                    <div class="col-auto"><i class="bi bi-boxes fs-2 text-muted"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- Charts -->
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-white py-3">
                <h6 class="m-0 font-weight-bold text-primary">Import vs Export Value</h6>
            </div>
            <div class="card-body">
                <canvas id="mainChart" height="100"></canvas>
            </div>
        </div>
        
        <!-- Recent Transactions -->
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h6 class="mb-0">Recent Imports</h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0 text-sm">
                                <thead>
                                    <tr><th>Number</th><th>Supplier</th><th>Amount</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach($recent_imports as $imp): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($imp['import_number']); ?></td>
                                        <td><?php echo htmlspecialchars($imp['company_name']); ?></td>
                                        <td>$<?php echo number_format($imp['total_amount'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h6 class="mb-0">Recent Exports</h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0 text-sm">
                                <thead>
                                    <tr><th>Number</th><th>Customer</th><th>Amount</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach($recent_exports as $exp): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($exp['export_number']); ?></td>
                                        <td><?php echo htmlspecialchars($exp['company_name']); ?></td>
                                        <td>$<?php echo number_format($exp['total_amount'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- Low Stock Alerts -->
        <div class="card shadow-sm border-danger">
            <div class="card-header bg-danger text-white">
                <h6 class="mb-0"><i class="bi bi-exclamation-triangle-fill me-2"></i>Low Stock Alerts</h6>
            </div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush">
                    <?php if (count($low_stock) > 0): ?>
                        <?php foreach($low_stock as $item): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo htmlspecialchars($item['product_name']); ?></strong>
                                <div class="small text-muted"><?php echo htmlspecialchars($item['product_code']); ?></div>
                            </div>
                            <span class="badge bg-danger rounded-pill"><?php echo $item['available_quantity']; ?> left</span>
                        </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="list-group-item text-center text-muted py-3">No low stock items.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <!-- Summary Box -->
        <div class="card mt-4 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Business Summary</h6>
            </div>
            <div class="card-body">
                <p><strong>Suppliers:</strong> <?php echo number_format($stats['suppliers']); ?></p>
                <p><strong>Customers:</strong> <?php echo number_format($stats['customers']); ?></p>
                <p><strong>Total Import Orders:</strong> <?php echo number_format($stats['imports']); ?></p>
                <p class="mb-0"><strong>Total Export Orders:</strong> <?php echo number_format($stats['exports']); ?></p>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var ctx = document.getElementById('mainChart').getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Imports', 'Exports'],
            datasets: [{
                label: 'Total Value ($)',
                data: [<?php echo $stats['import_val']; ?>, <?php echo $stats['export_val']; ?>],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(75, 192, 192, 0.6)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
