<?php
// admin/inventory/index.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 15;
$offset = ($page - 1) * $limit;

$query = "SELECT i.*, p.product_code, p.product_name, p.reorder_level 
          FROM inventory i 
          JOIN products p ON i.product_id = p.id 
          WHERE p.product_name LIKE :search OR p.product_code LIKE :search 
          ORDER BY p.product_name ASC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($query);
$search_param = "%$search%";
$stmt->bindParam(':search', $search_param, PDO::PARAM_STR);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Inventory Stock</h2>
    <a href="history.php" class="btn btn-outline-primary"><i class="bi bi-clock-history me-1"></i> Transaction History</a>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white py-3">
        <form class="d-flex align-items-center" method="GET">
            <input type="text" name="search" class="form-control me-2" placeholder="Search product..." value="<?php echo htmlspecialchars($search); ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Reorder Level</th>
                        <th>Total Qty</th>
                        <th>Available Qty</th>
                        <th>Status</th>
                        <th>Last Updated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($items) > 0): ?>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_code']); ?></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td><?php echo $item['reorder_level']; ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>
                                <strong><?php echo $item['available_quantity']; ?></strong>
                            </td>
                            <td>
                                <?php if($item['available_quantity'] <= $item['reorder_level']): ?>
                                    <span class="badge bg-danger">Low Stock</span>
                                <?php else: ?>
                                    <span class="badge bg-success">In Stock</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d M Y, H:i', strtotime($item['last_updated'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4">No inventory records found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
