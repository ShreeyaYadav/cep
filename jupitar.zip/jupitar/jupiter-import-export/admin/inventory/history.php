<?php
// admin/inventory/history.php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$query = "SELECT t.*, p.product_name, p.product_code, u.name as user_name 
          FROM inventory_transactions t 
          JOIN products p ON t.product_id = p.id 
          JOIN users u ON t.created_by = u.id 
          ORDER BY t.transaction_date DESC LIMIT :limit OFFSET :offset";
$stmt = $conn->prepare($query);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Inventory Transaction History</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Inventory</a>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Product</th>
                        <th>Type</th>
                        <th>Reference ID</th>
                        <th>Qty Change</th>
                        <th>Balance After</th>
                        <th>Recorded By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($items) > 0): ?>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?php echo date('d M Y, H:i', strtotime($item['transaction_date'])); ?></td>
                            <td><?php echo htmlspecialchars($item['product_code'] . ' - ' . $item['product_name']); ?></td>
                            <td>
                                <?php 
                                $bg = 'secondary';
                                if($item['transaction_type'] == 'IMPORT') $bg = 'success';
                                elseif($item['transaction_type'] == 'EXPORT') $bg = 'primary';
                                ?>
                                <span class="badge bg-<?php echo $bg; ?>"><?php echo $item['transaction_type']; ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($item['reference_id']); ?></td>
                            <td>
                                <?php if($item['transaction_type'] == 'IMPORT'): ?>
                                    <span class="text-success">+<?php echo $item['quantity']; ?></span>
                                <?php else: ?>
                                    <span class="text-danger">-<?php echo $item['quantity']; ?></span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo $item['balance_after']; ?></strong></td>
                            <td><?php echo htmlspecialchars($item['user_name']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4">No transactions found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
