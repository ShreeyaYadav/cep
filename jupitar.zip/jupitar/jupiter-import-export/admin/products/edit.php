<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/products/index.php');
}

$id = (int)$_GET['id'];
$error = '';

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    redirect('/jupiter-import-export/admin/products/index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_code = trim($_POST['product_code']);
    $product_name = trim($_POST['product_name']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $unit = trim($_POST['unit']);
    $price = trim($_POST['price']);
    $reorder_level = trim($_POST['reorder_level']);
    $status = trim($_POST['status']);
    
    // Check if code exists for another ID
    $stmt = $conn->prepare("SELECT id FROM products WHERE product_code = ? AND id != ?");
    $stmt->execute([$product_code, $id]);
    if ($stmt->rowCount() > 0) {
        $error = 'Product Code already exists.';
    } else {
        $query = "UPDATE products SET product_code = ?, product_name = ?, category = ?, description = ?, unit = ?, price = ?, reorder_level = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $exec_vars = [$product_code, $product_name, $category, $description, $unit, $price, $reorder_level, $status, $id];
        if ($stmt->execute($exec_vars)) {
            setFlashMessage('success', 'Product updated successfully.');
            redirect('/jupiter-import-export/admin/products/index.php');
        } else {
            $error = 'Failed to update product.';
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Edit Product</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Code <span class='text-danger'>*</span></label>
                    <input type="text" name="product_code" class="form-control" required  value="<?php echo htmlspecialchars($item["product_code"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Name <span class='text-danger'>*</span></label>
                    <input type="text" name="product_name" class="form-control" required  value="<?php echo htmlspecialchars($item["product_name"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Category <span class='text-danger'>*</span></label>
                    <input type="text" name="category" class="form-control" required  value="<?php echo htmlspecialchars($item["category"]); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Description </label>
                    <textarea name="description" class="form-control" ><?php echo htmlspecialchars($item["description"]); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Unit <span class='text-danger'>*</span></label>
                    <input type="text" name="unit" class="form-control" required  value="<?php echo htmlspecialchars($item["unit"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Price <span class='text-danger'>*</span></label>
                    <input type="number" name="price" class="form-control" required step="0.01" value="<?php echo htmlspecialchars($item["price"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reorder Level <span class='text-danger'>*</span></label>
                    <input type="number" name="reorder_level" class="form-control" required step="0.01" value="<?php echo htmlspecialchars($item["reorder_level"]); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status <span class='text-danger'>*</span></label>
                    <select name="status" class="form-select" required>
                <option value="active" <?php echo $item["status"] == 'active' ? 'selected' : ''; ?>>Active</option>
                <option value="inactive" <?php echo $item["status"] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
            </select>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
