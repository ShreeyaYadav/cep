<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_code = trim($_POST['product_code']);
    $product_name = trim($_POST['product_name']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $unit = trim($_POST['unit']);
    $price = trim($_POST['price']);
    $reorder_level = trim($_POST['reorder_level']);
    $status = trim($_POST['status']);
    
    // Check if code exists
    $stmt = $conn->prepare("SELECT id FROM products WHERE product_code = ?");
    $stmt->execute([$product_code]);
    if ($stmt->rowCount() > 0) {
        $error = 'Product Code already exists.';
    } else {
        $query = "INSERT INTO products (product_code, product_name, category, description, unit, price, reorder_level, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if ($stmt->execute([$product_code, $product_name, $category, $description, $unit, $price, $reorder_level, $status])) {
            
            $product_id = $conn->lastInsertId();
            $stmt = $conn->prepare("INSERT INTO inventory (product_id, quantity, reserved_quantity, available_quantity) VALUES (?, 0, 0, 0)");
            $stmt->execute([$product_id]);
        
            setFlashMessage('success', 'Product added successfully.');
            redirect('/jupiter-import-export/admin/products/index.php');
        } else {
            $error = 'Failed to add product.';
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Add Product</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Code <span class='text-danger'>*</span></label>
                    <input type="text" name="product_code" class="form-control" required >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Name <span class='text-danger'>*</span></label>
                    <input type="text" name="product_name" class="form-control" required >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Category <span class='text-danger'>*</span></label>
                    <input type="text" name="category" class="form-control" required >
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Description </label>
                    <textarea name="description" class="form-control" ></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Unit <span class='text-danger'>*</span></label>
                    <input type="text" name="unit" class="form-control" required >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Price <span class='text-danger'>*</span></label>
                    <input type="number" name="price" class="form-control" required step="0.01">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reorder Level <span class='text-danger'>*</span></label>
                    <input type="number" name="reorder_level" class="form-control" required step="0.01">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Status <span class='text-danger'>*</span></label>
                    <select name="status" class="form-select" required>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
                </div>
            </div>
            <hr>
            <button type="submit" class="btn btn-primary">Save Product</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
