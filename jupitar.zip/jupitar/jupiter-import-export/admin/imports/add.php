<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

$error = '';

$suppliers = $conn->query("SELECT id, company_name FROM suppliers WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);
$products = $conn->query("SELECT id, product_name, price FROM products WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $import_number = trim($_POST['import_number']);
    $supplier_id = (int)$_POST['supplier_id'];
    $import_date = $_POST['import_date'];
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    $unit_cost = (float)$_POST['unit_cost'];
    $shipping_cost = (float)$_POST['shipping_cost'];
    $customs_cost = (float)$_POST['customs_cost'];
    $remarks = trim($_POST['remarks']);
    
    $total_amount = ($quantity * $unit_cost) + $shipping_cost + $customs_cost;
    
    // check unique
    $stmt = $conn->prepare("SELECT id FROM imports WHERE import_number = ?");
    $stmt->execute([$import_number]);
    if ($stmt->rowCount() > 0) {
        $error = 'Import Number already exists.';
    } elseif ($quantity <= 0) {
        $error = 'Quantity must be greater than zero.';
    } else {
        $query = "INSERT INTO imports (import_number, supplier_id, import_date, product_id, quantity, unit_cost, total_amount, shipping_cost, customs_cost, status, remarks, created_by) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)";
        $stmt = $conn->prepare($query);
        if ($stmt->execute([$import_number, $supplier_id, $import_date, $product_id, $quantity, $unit_cost, $total_amount, $shipping_cost, $customs_cost, $remarks, $_SESSION['user_id']])) {
            setFlashMessage('success', 'Import created successfully. Stock will update when status is Received.');
            redirect('/jupiter-import-export/admin/imports/index.php');
        } else {
            $error = 'Failed to create import.';
        }
    }
}

include '../../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">New Import</h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Import Number <span class="text-danger">*</span></label>
                    <input type="text" name="import_number" class="form-control" required value="IMP-<?php echo time(); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Import Date <span class="text-danger">*</span></label>
                    <input type="date" name="import_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier <span class="text-danger">*</span></label>
                    <select name="supplier_id" class="form-select" required>
                        <option value="">Select Supplier</option>
                        <?php foreach($suppliers as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['company_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product <span class="text-danger">*</span></label>
                    <select name="product_id" class="form-select" required>
                        <option value="">Select Product</option>
                        <?php foreach($products as $p): ?>
                            <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['product_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3 mb-3">
                    <label class="form-label">Quantity <span class="text-danger">*</span></label>
                    <input type="number" name="quantity" class="form-control" required min="1">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Unit Cost ($) <span class="text-danger">*</span></label>
                    <input type="number" name="unit_cost" step="0.01" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Shipping Cost ($)</label>
                    <input type="number" name="shipping_cost" step="0.01" class="form-control" value="0">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Customs Cost ($)</label>
                    <input type="number" name="customs_cost" step="0.01" class="form-control" value="0">
                </div>
                
                <div class="col-md-12 mb-3">
                    <label class="form-label">Remarks</label>
                    <textarea name="remarks" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Create Import</button>
        </form>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
