<?php
require_once '../../config/database.php';
require_once '../../includes/auth.php';

if (!isset($_GET['id'])) {
    redirect('/jupiter-import-export/admin/imports/index.php');
}

$id = (int)$_GET['id'];
$error = '';

$stmt = $conn->prepare("
    SELECT i.*, p.product_name, p.product_code, s.company_name, u.name as created_by_name 
    FROM imports i 
    JOIN products p ON i.product_id = p.id 
    JOIN suppliers s ON i.supplier_id = s.id 
    JOIN users u ON i.created_by = u.id 
    WHERE i.id = ?
");
$stmt->execute([$id]);
$import = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$import) {
    redirect('/jupiter-import-export/admin/imports/index.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    if ($import['status'] != 'Received' && $import['status'] != 'Cancelled') {
        $stmt = $conn->prepare("UPDATE imports SET status = ? WHERE id = ?");
        
        if ($stmt->execute([$new_status, $id])) {
            // Inventory Logic!
            if ($new_status == 'Received') {
                updateInventoryOnImport($conn, $import['product_id'], $import['quantity']);
                
                // Fetch balance
                $bal_stmt = $conn->prepare("SELECT available_quantity FROM inventory WHERE product_id = ?");
                $bal_stmt->execute([$import['product_id']]);
                $balance = $bal_stmt->fetchColumn();
                
                recordInventoryTransaction($conn, $import['product_id'], 'IMPORT', $import['import_number'], $import['quantity'], $balance, $_SESSION['user_id']);
                setFlashMessage('success', 'Import marked as Received. Inventory has been updated.');
            } else {
                setFlashMessage('success', 'Import status updated.');
            }
            redirect('/jupiter-import-export/admin/imports/view.php?id=' . $id);
        }
    }
}

include '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0">Import Details: <?php echo htmlspecialchars($import['import_number']); ?></h2>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if ($msg = displayFlashMessage('success')): ?>
    <div class="alert alert-success"><?php echo $msg; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0">Transaction Information</h6>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Supplier</div>
                    <div class="col-sm-8 fw-bold"><?php echo htmlspecialchars($import['company_name']); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Date</div>
                    <div class="col-sm-8"><?php echo date('d M Y', strtotime($import['import_date'])); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Product</div>
                    <div class="col-sm-8"><?php echo htmlspecialchars($import['product_code'] . ' - ' . $import['product_name']); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Quantity</div>
                    <div class="col-sm-8"><?php echo $import['quantity']; ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-4 text-muted">Remarks</div>
                    <div class="col-sm-8"><?php echo nl2br(htmlspecialchars($import['remarks'])); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-white">
                <h6 class="mb-0">Financials & Status</h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Unit Cost:</span>
                    <span>$<?php echo number_format($import['unit_cost'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Product Total:</span>
                    <span>$<?php echo number_format($import['quantity'] * $import['unit_cost'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Shipping:</span>
                    <span>$<?php echo number_format($import['shipping_cost'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Customs:</span>
                    <span>$<?php echo number_format($import['customs_cost'], 2); ?></span>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-3 fw-bold">
                    <span>Grand Total:</span>
                    <span class="text-primary">$<?php echo number_format($import['total_amount'], 2); ?></span>
                </div>
                
                <div class="mb-3">
                    <label class="text-muted mb-1 d-block">Current Status:</label>
                    <h5>
                        <?php 
                        $bg = 'secondary';
                        if($import['status'] == 'Received') $bg = 'success';
                        elseif($import['status'] == 'In Transit') $bg = 'info';
                        elseif($import['status'] == 'Pending') $bg = 'warning text-dark';
                        elseif($import['status'] == 'Cancelled') $bg = 'danger';
                        ?>
                        <span class="badge bg-<?php echo $bg; ?>"><?php echo $import['status']; ?></span>
                    </h5>
                </div>
                
                <?php if ($import['status'] == 'Pending' || $import['status'] == 'In Transit'): ?>
                <form method="POST" action="">
                    <input type="hidden" name="update_status" value="1">
                    <div class="mb-3">
                        <select name="status" class="form-select">
                            <option value="Pending" <?php echo $import['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="In Transit" <?php echo $import['status'] == 'In Transit' ? 'selected' : ''; ?>>In Transit</option>
                            <option value="Received">Received (Updates Inventory)</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Update Status</button>
                </form>
                <?php else: ?>
                    <div class="alert alert-light border">
                        Status is final. Cannot be changed.
                    </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
